const packData = [
    // LOTE 1 (Do arquivo 'guardar.zip')
    { nome: "Ai ai ai Tatuagem", tipo: "som", arquivo: "ai-ai-ai-tatuagem.mp3" },
    { nome: "Banido", tipo: "som", arquivo: "banido_FzWiL58.mp3" },
    { nome: "Brutal: Acabou pro Beta", tipo: "meme", arquivo: "brutal-acabou-pro-beta-globo.mp3" },
    { nome: "Cala a boca Uriel", tipo: "meme", arquivo: "cala-boca-uriel.mp3" },
    { nome: "Cebolinha Maltratando", tipo: "meme", arquivo: "cebolinha-maltratando.mp3" },
    { nome: "Galinha na Árvore", tipo: "som", arquivo: "chicken-on-tree-screaming.mp3" },
    { nome: "Corte Rápido", tipo: "som", arquivo: "corte-rapido.mp3" },
    { nome: "Dexter Meme", tipo: "meme", arquivo: "dexter-meme.mp3" },
    { nome: "Fahhhhhhhhhhh", tipo: "som", arquivo: "fahhhhhhhhhhhhhh.mp3" },

    // LOTE 0 (Do primeiro arquivo enviado)
    { nome: "Gyro: Universo", tipo: "meme", arquivo: "foi-quando-gyro-finally-entendeu.mp3" },
    { nome: "Galaxy Meme", tipo: "meme", arquivo: "galaxy-meme.mp3" },
    { nome: "Oi Oi Oe", tipo: "som", arquivo: "oi-oi-oe-oi-a-eye-eye.mp3" },
    { nome: "Pega o Jack", tipo: "meme", arquivo: "pega-o-jack.mp3" },
    { nome: "Pou Estourado", tipo: "som", arquivo: "pou-estourado_zIWCpMy.mp3" },
    { nome: "Rizz Sound", tipo: "som", arquivo: "rizz-sound-effect.mp3" },
    { nome: "Zap Estourado", tipo: "som", arquivo: "som-do-zap-zap-estourado.mp3" },
    { nome: "Bob Fail", tipo: "som", arquivo: "spongebob-fail.mp3" },
    { nome: "Vine Boom", tipo: "som", arquivo: "vine-boom.mp3" },
    { nome: "Sem Aura", tipo: "meme", arquivo: "voce-nao-tem-aura.mp3" }
];

let currentAudio = null;
let currentBtn = null;

function renderPack(filter = 'all') {
    const container = document.getElementById('pack-container');
    container.innerHTML = '';
    
    const filtered = filter === 'all' ? packData : packData.filter(i => i.tipo === filter);

    filtered.forEach((item, index) => {
        const card = document.createElement('div');
        card.className = 'item-card';
        card.innerHTML = `
            <div class="item-info">
                <span class="item-name">${item.nome}</span>
                <span class="item-type">${item.tipo.toUpperCase()}</span>
            </div>
            <div class="btn-group">
                <button class="control-btn play-btn" onclick="togglePlay('${item.arquivo}', this)">OUVIR</button>
                <button class="control-btn download-btn" onclick="downloadFile('${item.arquivo}')">BAIXAR</button>
            </div>
        `;
        container.appendChild(card);
    });
}

function togglePlay(file, btn) {
    if (currentAudio && !currentAudio.paused) {
        currentAudio.pause();
        currentBtn.classList.remove('playing');
        currentBtn.innerText = "OUVIR";
        if (currentBtn === btn) return; 
    }

    currentAudio = new Audio(file);
    currentBtn = btn;
    
    currentAudio.play();
    btn.classList.add('playing');
    btn.innerText = "PARAR";

    currentAudio.onended = () => {
        btn.classList.remove('playing');
        btn.innerText = "OUVIR";
    };
}

function filterPack(type, btn) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderPack(type);
}

function downloadFile(file) {
    const link = document.createElement('a');
    link.href = file;
    link.download = file;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

renderPack();
